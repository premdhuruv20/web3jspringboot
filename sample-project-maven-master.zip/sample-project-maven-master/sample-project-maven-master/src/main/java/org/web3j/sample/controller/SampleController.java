package org.web3j.sample.controller;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;
import org.web3j.crypto.Credentials;
import org.web3j.protocol.Web3j;
import org.web3j.sample.wrapper.Learn;
import org.web3j.tx.gas.ContractGasProvider;

import io.swagger.annotations.ApiOperation;


@RestController
class SampleController {
	private static final Logger logger = LoggerFactory.getLogger(SampleController.class);


	@Autowired
	private Web3j web3j;
	
	@Autowired
	ContractGasProvider gasProvider;
	
	@Autowired
	 Credentials credentials;


	
	@ApiOperation(value = "Api for fetching accounts in keystore", response = ResponseEntity.class)
	@PostMapping(value="deploy",produces=MediaType.APPLICATION_JSON_UTF8_VALUE)
	public String deploy() throws Exception{
		
		Learn string = Learn.deploy(web3j, credentials, gasProvider).send();
		return string.getContractAddress();
	}
}
	 


	  // Aggregate root
	  // tag::get-aggregate-root[]
	 




